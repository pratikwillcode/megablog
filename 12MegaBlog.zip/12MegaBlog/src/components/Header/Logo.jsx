import React from 'react'
import { Link } from 'react-router-dom'

function Logo() {
  return (
    <div className=' w-16 h-16'>
      <Link to='/'>
      <img src='/Logo.jpg' alt='logo' />
      </Link>
    </div>
  )
}

export default Logo