import React from 'react'
import {Signup as SignupComponent} from '../components'

function Signup() {
  return (
    <div className=''>
        <SignupComponent />
    </div>
  )
}

export default Signup