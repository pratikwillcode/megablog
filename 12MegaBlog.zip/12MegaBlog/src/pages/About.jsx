import Container from "../components/container/Container";

import { AiFillHeart } from "react-icons/ai";
import { AiFillGithub } from "react-icons/ai";
import { AiOutlineTwitter } from "react-icons/ai";
function About() {
  return (
      <div className="flex flex-col items-center justify-center min-h-screen py-2">
        <Container>
          <div className="text-center px-8">
              <h1 className="text-4xl font-bold mb-4">About Us</h1>
              <p className="text-lg text-gray-700 mb-4">
              Welcome to BlogBash, your go-to destination for fresh perspectives, insightful commentary, and lively discussions on the latest happenings around the globe. At BlogBash, we believe in the power of storytelling and the importance of fostering an inclusive community where voices from all walks of life are heard and valued.
              </p>
              <p className="text-lg text-gray-700 mb-4">
              Our mission is simple: to provide a platform for individuals like you to express your thoughts, share your experiences, and engage in meaningful conversations about the world we live in. Whether you're passionate about politics, technology, culture, travel, or anything in between, BlogBash is the place to be.
              </p>
              <p className="text-lg text-gray-700 mb-4">
              What sets us apart is our commitment to diversity, authenticity, and quality. We welcome bloggers of all backgrounds and viewpoints, encouraging a rich tapestry of perspectives that reflects the complexity of our world. From seasoned writers to aspiring wordsmiths, everyone has a place at BlogBash.
              </p>
              <p className="text-lg text-gray-700 mb-4">
              So, join us at BlogBash and let your voice be heard. Together, we'll explore the world, one blog post at a time. Welcome to the conversation. Welcome to BlogBash.
              </p>
              

          </div>
          <div className="w-full px-8  flex flex-col justify-center items-center">
              <h2 className="text-2xl font-bold mb-4 max-sm:flex max-sm:flex-col max-sm:items-center"><span>Our Team</span> <span className=" text-sm font-normal">actually its just me.😉</span></h2>
              <div className="flex flex-wrap -mx-4 ">
                  {/* Replace with actual team members */}
                  {['Pratik Awari'].map((name, index) => (
                      <div key={index} className=" w-48 mb-4">
                          <div className="bg-white shadow rounded p-4 text-center">
                              <div className="mb-4">
                                  {/* Replace with actual image */}
                                  <img src="/profile_pic_resized.png" alt={name} className="mx-auto rounded-full w-24 h-24 object-cover" />
                              </div>
                              <h3 className="text-xl font-bold">{name}</h3>
                              <p className="text-gray-600">Owner</p>
                          </div>
                      </div>
                  ))}
              </div>
          </div>
          <div className="mt-auto">
              <footer className="w-full text-center border-t border-grey p-4 pin-b flex flex-col items-center">
              <div className=' flex items-center'>Made with <span className=' text-red-600 px-1'><AiFillHeart /></span>By<a href='https://www.linkedin.com/in/pratik-awari-608908218/' target='_blank' className='px-1 underline'>Pratik</a>
</div>
<div className='flex p-2 text-2xl gap-2'>
                    <a href='https://github.com/pratikwillcode' target='_blank'><AiFillGithub /></a>
                    <a href='https://twitter.com/i/flow/login?redirect_after_login=%2FPratikAwari28' target='_blank'><AiOutlineTwitter /></a>
                </div>
              </footer>
          </div>
          </Container>
      </div>
  );
}

export default About;