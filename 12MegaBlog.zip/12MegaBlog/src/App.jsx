import { useState, useEffect } from 'react'
import { useDispatch } from 'react-redux'
import './App.css'
import authService from './appwrite/auth'
import { login, logout, setProfileDetails } from './store/authSlice'
import { Header, Footer } from './components/index'
import { Outlet } from 'react-router-dom'
import profileSerive from './appwrite/config'
import { useSelector } from 'react-redux'

function App() {
  const [loading, setLoading] = useState(true)

  const isLoggedIn = useSelector(state => state.status)
  const [userId, setUserId] = useState("")
  const dispatch = useDispatch()

  useEffect(() => {
    authService.getCurrentuser()
      .then((userData) => {
        if (userData) {
          setUserId(userData.$id)
          dispatch(login( {userData} ))
        } else {
          setUserId('')
          dispatch(logout())
        }
      }).catch((e) => {
        console.log("Get Current User Failed" + e.message);
      }).finally(() => {
        setLoading(false)
      })

  }, [isLoggedIn])

  useEffect(() => {
    if (isLoggedIn && userId) {
      profileSerive.getProfileDetails(userId)
        .then((profileDetails) => {
          if(profileDetails){

            dispatch(setProfileDetails(profileDetails))
          }
        }).catch((e) => {
          console.log("Get Profile Details Failed" + e.message);
        })
    }
  }, [isLoggedIn, userId])

  return !loading ? (<div className='min-h-screen flex flex-wrap content-between '>
    <div className='w-full block'>
      <Header />
      <main>

        <Outlet />
      </main>
      <Footer />
    </div>
  </div>) : null
}

export default App
